export interface OptionInterface {
  method: string,
  headers: object,
  mode: string,
  cache?: string,
  body?: string
}