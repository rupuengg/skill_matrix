export interface SpinnerProps {
  spinner?: boolean
}