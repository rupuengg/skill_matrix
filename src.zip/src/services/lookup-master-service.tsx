import { reqOptions } from "../helpers/common";
// import { OptionInterface } from '../interfaces/option.interface';

const getProficiencyLevel = async (type: string) => {
  const request: Request = reqOptions(
    `http://localhost:8080/api/1.0/lookupmaster/${type}`,
    "GET"
  );
  return fetch(request)
    .then((res: any) => res.json())
    .then((res: any) => {
      return res;
    });
};
const lookupMasterService = {
  getProficiencyLevel
};

export default lookupMasterService;
