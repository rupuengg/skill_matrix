import React, { useEffect, FormEvent } from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import {
  getEmployeeSkills,
  deleteEmployeeSkill
} from "../../../actions/employee-skill.action";

const EmployeeSkill = (props: any) => {
  useEffect(() => {
    props.getEmployeeSkills();
  }, [props.removeEmpId]);

  const handleDelete = (e: FormEvent<HTMLAnchorElement>, skillId: number) => {
    e.preventDefault();
    props.deleteEmployeeSkill(skillId);
  };

  console.log("llllll", props.skills);
  debugger;
  return (
    <div>
      <ol className="breadcrumb">
        <li className="breadcrumb-item active">Skills</li>
        <li className="add-new">
          <Link to="/employee/skills/create">
            <span className="fa fa-plus"></span> Add New
          </Link>
        </li>
      </ol>
      <div className="card mb-3">
        <div className="card-body">
          <div className="">
            <div
              id="dataTable_wrapper"
              className="dataTables_wrapper dt-bootstrap4"
            >
              <h4>Project: </h4>
              <h5>Must to have:</h5>
              <div className="row">
                <div className="col-sm-12">
                  <table
                    className="table table-bordered dataTable"
                    id="dataTable"
                  >
                    <thead>
                      <tr role="row">
                        <th
                          className="sorting_asc"
                          aria-controls="dataTable"
                          aria-sort="ascending"
                          aria-label="Name: activate to sort column descending"
                        >
                          Skillname
                        </th>
                        <th
                          className="sorting_asc"
                          aria-controls="dataTable"
                          aria-sort="ascending"
                          aria-label="Name: activate to sort column descending"
                        >
                          Proficiency
                        </th>
                        <th
                          className="sorting_asc"
                          aria-controls="dataTable"
                          aria-sort="ascending"
                          aria-label="Name: activate to sort column descending"
                        >
                          Relevant exp in month(s)
                        </th>
                        {/* <th
                          className="sorting_asc"
                          aria-controls="dataTable"
                          aria-sort="ascending"
                          aria-label="Name: activate to sort column descending"
                        >
                          Last used
                        </th> */}
                        <th
                          aria-controls="dataTable"
                          aria-label="Age: activate to sort column ascending"
                        >
                          &nbsp;
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {props.skills.map((skill: any) => (
                        <tr className="odd" key={skill.id}>
                          <td className="sorting_1">
                            {skill.skill && skill.skill.skill_name}
                          </td>
                          <td className="sorting_1">
                            {skill.LookUpMasters[0].Value}
                          </td>
                          <td className="sorting_1">{skill.exp_in_month}</td>
                          {/* <td className="sorting_1">{skill.last_used}</td> */}
                          <td>
                            <Link to={"/employee/skills/update/" + skill.id}>
                              <i className="fa fa-edit"></i>
                            </Link>
                            &nbsp;&nbsp;&nbsp;
                            {/* <Link
                              to="/"
                              onClick={e => handleDelete(e, skill.id)}
                            >
                              <i className="fa fa-trash"></i>
                            </Link> */}
                          </td>
                        </tr>
                      ))}

                      {!props.skills.length && (
                        <tr>
                          <td colSpan={5}>No records found</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const mapStoreToProps = (store: any) => {
  return {
    skills: store.employeeSkill.lists,
    removeEmpId: store.employeeSkill.delete_id
  };
};

export default connect(mapStoreToProps, {
  getEmployeeSkills,
  deleteEmployeeSkill
})(EmployeeSkill);
