export const LOOKUP_LIST = "LOOKUP_LIST";
export const LOOKUP_NO_DATA = "LOOKUP_NO_DATA";
