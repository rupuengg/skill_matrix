export const USER_LOGIN = 'USER_LOGIN';
export const USER_LOGIN_ERROR = 'USER_LOGIN_ERROR';
export const USER_LOGGOUT = 'USER_LOGGOUT';
export const USER_GET = 'USER_GET';
export const USER_PROFILE_UPDATE = 'USER_PROFILE_UPDATE';