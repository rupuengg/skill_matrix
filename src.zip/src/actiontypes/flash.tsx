export const FLASH_SHOW = 'FLASH_SHOW';
export const FLASH_HIDE = 'FLASH_HIDE';