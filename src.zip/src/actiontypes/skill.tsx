export const SKILL_LIST = 'SKILL_LIST';
export const SKILL_NO_DATA = 'SKILL_NO_DATA';
export const SKILL_ADD = 'SKILL_ADD';
export const SKILL_EDIT = 'SKILL_EDIT';
export const SKILL_UPDATE = 'SKILL_UPDATE';
export const SKILL_DELETE = 'SKILL_DELETE';