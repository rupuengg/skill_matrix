const express = require("express");
const validate = require("express-validation");
const router = express.Router();
const { authenticate } = require("../middlewares/auth-validator");
const lookUpMasterController = require("../controllers/lookup-master-controller");

router.get("/", authenticate, lookUpMasterController.getLookupMasterDatas);
router.get("/:id", authenticate, lookUpMasterController.getLookupMasterData);

// router.get('/', authenticate, skillController.getSkillAll);

module.exports = router;
