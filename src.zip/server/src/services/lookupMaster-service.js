const lookupMasterDao = require("../dao/lookupMaster-dao");
const getLookUpDetails = async filters => {
  const emps = await lookupMasterDao.getlookUpDatas(filters);
  return emps;
};

const getLookUpDetail = async type => {
  const lookupMasterData = await lookupMasterDao.getlookUpData({
    Type: type
  });
  //const lookupMasterData = type;
  return lookupMasterData;
};

const getSkills = async filters => {
  const emps = await skillDao.getSkills(filters);
  return emps;
};

const lookupMasterService = {
  getLookUpDetails,
  getLookUpDetail,
  getSkills
};
module.exports = lookupMasterService;
