const lookupMasterService = require("../services/lookupMaster-service");
const { OK, SERVER_ERROR } = require("../constants/httpConstant");

const getLookupMasterDatas = async (req, res) => {
  try {
    const emps = await lookupMasterService.getLookUpDetails();
    return res.status(OK).json({ data: emps });
    //return res.status(OK).json({ data: "Pooja" });
  } catch (err) {
    res.status(err.status || SERVER_ERROR).json(err);
  }
};

const getLookupMasterData = async (req, res) => {
  try {
    const emp = await lookupMasterService.getLookUpDetail(req.params.id);
    return res.status(OK).json({ data: emp });
    //return res.status(OK).json({ data: req.params.id });
  } catch (err) {
    res.status(err.status || SERVER_ERROR).json(err);
  }
};

const getSkills = async (req, res) => {
  try {
    const emps = await skillService.getSkills();
    return res.status(OK).json({ data: emps });
  } catch (err) {
    res.status(err.status || SERVER_ERROR).json(err);
  }
};
const lookupMasterController = {
  getLookupMasterData,
  getLookupMasterDatas,
  getSkills
};

module.exports = lookupMasterController;
