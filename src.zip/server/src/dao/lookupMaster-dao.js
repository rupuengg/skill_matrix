const lookupMasterModel = require("../models").LookUpMaster;
const skillModel = require("../models").skill;

const getlookUpDatas = async filters => {
  const emps = await lookupMasterModel.findAll({
    where: filters,
    order: [["LookUpID", "DESC"]]
  });
  return emps;
};

const getlookUpData = async filters => {
  const emp = await lookupMasterModel.findAll({
    where: filters,
    order: [["LookUpID", "ASC"]]
  });

  return emp;
};

const lookupMasterDao = {
  getlookUpData,
  getlookUpDatas
};
module.exports = lookupMasterDao;
